(function(){var P$=Clazz.newPackage("com.actelion.research.chem.chemicalspaces.synthon"),I$=[[0,'java.util.ArrayList','com.actelion.research.chem.StereoMolecule','java.util.HashMap','com.actelion.research.chem.chemicalspaces.synthon.SynthonReactor','com.actelion.research.chem.MoleculeStandardizer','com.actelion.research.chem.Coordinates']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SynthonReactor");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'react$java_util_List',  function (synthons) {
var bonds=Clazz.array(Integer.TYPE, [10]);
var deletionMap=Clazz.new_($I$(1,1));
var atomMap=Clazz.new_($I$(1,1));
var buildingBlocks=Clazz.new_($I$(1,1));
synthons.stream$().forEach$java_util_function_Consumer(((P$.SynthonReactor$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "SynthonReactor$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$com_actelion_research_chem_StereoMolecule','accept$O'],  function (e) { return (this.$finals$.buildingBlocks.add$O(Clazz.new_($I$(2,1).c$$com_actelion_research_chem_Molecule,[e])));});
})()
), Clazz.new_(P$.SynthonReactor$lambda1.$init$,[this, {buildingBlocks:buildingBlocks}])));
buildingBlocks.forEach$java_util_function_Consumer((P$.SynthonReactor$lambda2$||(P$.SynthonReactor$lambda2$=(((P$.SynthonReactor$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "SynthonReactor$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$com_actelion_research_chem_StereoMolecule','accept$O'],  function (e) { return (e.ensureHelperArrays$I(31));});
})()
), Clazz.new_(P$.SynthonReactor$lambda2.$init$,[this, null]))))));
var rgrps=Clazz.new_($I$(3,1));
for (var m=0; m < buildingBlocks.size$(); m++) {
var bb=buildingBlocks.get$I(m);
for (var a=0; a < bb.getAtoms$(); a++) {
var atomNo=bb.getAtomicNo$I(a);
if (atomNo >= 92) {
rgrps.putIfAbsent$O$O(Integer.valueOf$I(atomNo - 92 + 1), Clazz.new_($I$(1,1)));
var connAtom=bb.getConnAtom$I$I(a, 0);
var b=bb.getBond$I$I(a, connAtom);
var upDownIdentifier=bb.getBondAtom$I$I(0, b) == a ? -1 : 1;
var bondType=bb.getBondType$I(b);
rgrps.get$O(Integer.valueOf$I(atomNo - 92 + 1)).add$O(Clazz.array(Integer.TYPE, -1, [m, connAtom, a, upDownIdentifier, bondType]));
var bondOrder=bb.getConnBondOrder$I$I(a, 0);
bonds[0]=bondOrder;
}}
}
var keysToDelete=Clazz.new_($I$(1,1));
rgrps.forEach$java_util_function_BiConsumer(((P$.SynthonReactor$lambda3||
(function(){/*m*/var C$=Clazz.newClass(P$, "SynthonReactor$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.BiConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$Integer$java_util_List','accept$O$O'],  function (k, v) {
if (v.size$() < 2) this.$finals$.keysToDelete.add$O(k);
});
})()
), Clazz.new_(P$.SynthonReactor$lambda3.$init$,[this, {keysToDelete:keysToDelete}])));
rgrps.keySet$().removeAll$java_util_Collection(keysToDelete);
rgrps.forEach$java_util_function_BiConsumer(((P$.SynthonReactor$lambda4||
(function(){/*m*/var C$=Clazz.newClass(P$, "SynthonReactor$lambda4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.BiConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$Integer$java_util_List','accept$O$O'],  function (k, v) {
this.$finals$.buildingBlocks.get$I(v.get$I(0)[0]).markAtomForDeletion$I(v.get$I(0)[2]);
this.$finals$.buildingBlocks.get$I(v.get$I(1)[0]).markAtomForDeletion$I(v.get$I(1)[2]);
var bb1=v.get$I(0)[0];
var bb2=v.get$I(1)[0];
var u1=v.get$I(0)[2];
var u2=v.get$I(1)[2];
var a1=v.get$I(0)[1];
var a2=v.get$I(1)[1];
$I$(4,"alignSynthons$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$I$I$I$I",[this.$finals$.buildingBlocks.get$I(bb1), this.$finals$.buildingBlocks.get$I(bb2), u1, u2, a1, a2]);
});
})()
), Clazz.new_(P$.SynthonReactor$lambda4.$init$,[this, {buildingBlocks:buildingBlocks}])));
for (var m=0; m < buildingBlocks.size$(); m++) {
var bb=buildingBlocks.get$I(m);
var map=bb.deleteMarkedAtomsAndBonds$();
deletionMap.add$O(map);
var m_=m;
rgrps.forEach$java_util_function_BiConsumer(((P$.SynthonReactor$lambda5||
(function(){/*m*/var C$=Clazz.newClass(P$, "SynthonReactor$lambda5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.BiConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$Integer$java_util_List','accept$O$O'],  function (k, v) {
v.stream$().forEach$java_util_function_Consumer(((P$.SynthonReactor$lambda5$6||
(function(){/*m*/var C$=Clazz.newClass(P$, "SynthonReactor$lambda5$6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$IA','accept$O'],  function (e) {
if (e[0] == this.$finals$.m_) e[1]=this.$finals$.map[e[1]];
});
})()
), Clazz.new_(P$.SynthonReactor$lambda5$6.$init$,[this, {map:this.$finals$.map,m_:this.$finals$.m_}])));
});
})()
), Clazz.new_(P$.SynthonReactor$lambda5.$init$,[this, {map:map,m_:m_}])));
}
var product=Clazz.new_($I$(2,1));
atomMap.add$O(product.addMolecule$com_actelion_research_chem_Molecule(buildingBlocks.get$I(0)));
for (var m=1; m < buildingBlocks.size$(); m++) {
var map=product.addMolecule$com_actelion_research_chem_Molecule(buildingBlocks.get$I(m));
atomMap.add$O(map);
var m_=m;
rgrps.forEach$java_util_function_BiConsumer(((P$.SynthonReactor$lambda6||
(function(){/*m*/var C$=Clazz.newClass(P$, "SynthonReactor$lambda6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.BiConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$Integer$java_util_List','accept$O$O'],  function (k, v) {
v.stream$().forEach$java_util_function_Consumer(((P$.SynthonReactor$lambda6$7||
(function(){/*m*/var C$=Clazz.newClass(P$, "SynthonReactor$lambda6$7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$IA','accept$O'],  function (e) {
if (e[0] == this.$finals$.m_) {
e[1]=this.$finals$.map[e[1]];
}});
})()
), Clazz.new_(P$.SynthonReactor$lambda6$7.$init$,[this, {m_:this.$finals$.m_,map:this.$finals$.map}])));
});
})()
), Clazz.new_(P$.SynthonReactor$lambda6.$init$,[this, {m_:m_,map:map}])));
}
rgrps.forEach$java_util_function_BiConsumer(((P$.SynthonReactor$lambda7||
(function(){/*m*/var C$=Clazz.newClass(P$, "SynthonReactor$lambda7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.BiConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$Integer$java_util_List','accept$O$O'],  function (k, v) {
var atom1=v.get$I(0)[1];
var atom2=v.get$I(1)[1];
var bondType=v.get$I(0)[4];
var upDownIdentifier=v.get$I(0)[3];
var bond=-1;
if (upDownIdentifier == 1) bond=this.$finals$.product.addBond$I$I(atom1, atom2);
 else bond=this.$finals$.product.addBond$I$I(atom2, atom1);
this.$finals$.product.setBondOrder$I$I(bond, this.$finals$.bonds[((k).$c() - 1)|0]);
this.$finals$.product.setBondType$I$I(bond, bondType);
});
})()
), Clazz.new_(P$.SynthonReactor$lambda7.$init$,[this, {product:product,bonds:bonds}])));
product.ensureHelperArrays$I(31);
try {
$I$(5).standardize$com_actelion_research_chem_StereoMolecule$I(product, 0);
product.ensureHelperArrays$I(31);
} catch (e1) {
if (Clazz.exceptionOf(e1,"Exception")){
e1.printStackTrace$();
} else {
throw e1;
}
}
return product;
}, 1);

Clazz.newMeth(C$, 'alignSynthons$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$I$I$I$I',  function (s1, s2, u1, u2, a1, a2) {
var v1=s1.getCoordinates$I(u1).subC$com_actelion_research_chem_Coordinates(s1.getCoordinates$I(a1));
var v2=s2.getCoordinates$I(a2).subC$com_actelion_research_chem_Coordinates(s2.getCoordinates$I(u2));
v1.unit$();
v2.unit$();
var alpha=Math.acos(v1.dot$com_actelion_research_chem_Coordinates(v2));
var n;
var cross=v1.cross$com_actelion_research_chem_Coordinates(v2);
if (cross.dist$() < 0.001 ) {
n=Clazz.new_($I$(6,1).c$$D$D$D,[0.0, 0.0, 1.0]);
alpha=3.141592653589793;
} else {
n=cross.unit$();
}var t=s1.getCoordinates$I(a1).scaleC$D(-1.0);
for (var a=0; a < s1.getAtoms$(); a++) {
s1.getCoordinates$I(a).add$com_actelion_research_chem_Coordinates(t);
}
t=s2.getCoordinates$I(u2).scaleC$D(-1.0);
for (var a=0; a < s2.getAtoms$(); a++) {
s2.getCoordinates$I(a).add$com_actelion_research_chem_Coordinates(t);
}
for (var a=0; a < s2.getAtoms$(); a++) {
var newCoords=C$.eulerRodrigues$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$D(s2.getCoordinates$I(a), n, -alpha);
s2.setAtomX$I$D(a, newCoords.x);
s2.setAtomY$I$D(a, newCoords.y);
s2.setAtomZ$I$D(a, newCoords.z);
}
}, 1);

Clazz.newMeth(C$, 'eulerRodrigues$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$D',  function (v, k, theta) {
var c1=v.scaleC$D(Math.cos(theta));
var c2=k.cross$com_actelion_research_chem_Coordinates(v).scale$D(Math.sin(theta));
var c3=k.scaleC$D(k.dot$com_actelion_research_chem_Coordinates(v) * (1 - Math.cos(theta)));
var vNew=c1.addC$com_actelion_research_chem_Coordinates(c2);
vNew.add$com_actelion_research_chem_Coordinates(c3);
return vNew;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:19 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
