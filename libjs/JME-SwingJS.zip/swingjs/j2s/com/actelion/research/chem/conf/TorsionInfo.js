(function(){var P$=Clazz.newPackage("com.actelion.research.chem.conf"),p$1={},p$2={},I$=[[0,'java.util.TreeMap','com.actelion.research.chem.conf.TorsionInfo','java.io.BufferedReader','java.io.FileReader','java.io.InputStreamReader','com.actelion.research.chem.conf.TorsionDetail']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "TorsionInfo");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['symmetryClass'],'O',['angle','short[]','range','short[][]','frequency','short[]','binSize','byte[]']]]

Clazz.newMeth(C$, 'c$$I',  function (symmetryClass) {
;C$.$init$.apply(this);
this.symmetryClass=symmetryClass;
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_conf_TorsionInfo',  function (ti) {
;C$.$init$.apply(this);
this.symmetryClass=ti.symmetryClass;
if (ti.angle != null ) {
this.angle=Clazz.array(Short.TYPE, [ti.angle.length]);
for (var i=0; i < this.angle.length; i++) this.angle[i]=((360 - ti.angle[this.angle.length - i - 1 ])|0);

}if (ti.range != null ) {
this.range=Clazz.array(Short.TYPE, [ti.range.length, 2]);
for (var i=0; i < this.range.length; i++) {
this.range[i][0]=((360 - ti.range[this.angle.length - i - 1 ][1])|0);
this.range[i][1]=((360 - ti.range[this.angle.length - i - 1 ][0])|0);
}
}if (ti.frequency != null ) {
this.frequency=Clazz.array(Short.TYPE, [ti.frequency.length]);
for (var i=0; i < this.frequency.length; i++) this.frequency[i]=ti.frequency[this.frequency.length - i - 1 ];

}if (ti.binSize != null ) {
this.binSize=Clazz.array(Byte.TYPE, [ti.binSize.length]);
for (var i=0; i < this.binSize.length; i++) this.binSize[i]=ti.binSize[this.binSize.length - i - 1 ];

}}, 1);

Clazz.newMeth(C$, 'get360DegreeAngles$',  function () {
var i1;
var i2;
var length;
var fullAngle=null;
switch (this.symmetryClass) {
case 1:
fullAngle=Clazz.array(Short.TYPE, [2 * this.angle.length]);
for (var i=0; i < this.angle.length; i++) {
fullAngle[i]=this.angle[i];
fullAngle[this.angle.length + i]=((180 + this.angle[i])|0);
}
return fullAngle;
case 2:
i1=(this.angle[0] == 0) ? 1 : 0;
i2=(this.angle[this.angle.length - 1] == 180) ? this.angle.length - 1 : this.angle.length;
length=i2 - i1;
fullAngle=Clazz.array(Short.TYPE, [this.angle.length + length]);
for (var i=0; i < this.angle.length; i++) fullAngle[i]=this.angle[i];

for (var i=i1; i < i2; i++) fullAngle[fullAngle.length - 1 - i  + i1]=((360 - this.angle[i])|0);

return fullAngle;
case 3:
i1=(this.angle[0] == 0) ? 1 : 0;
i2=(this.angle[this.angle.length - 1] == 90) ? this.angle.length - 1 : this.angle.length;
length=i2 - i1;
fullAngle=Clazz.array(Short.TYPE, [2 * this.angle.length + 2 * length]);
for (var i=0; i < this.angle.length; i++) {
fullAngle[i]=this.angle[i];
fullAngle[this.angle.length + length + i ]=((180 + this.angle[i])|0);
}
for (var i=i1; i < i2; i++) {
fullAngle[this.angle.length + length - 1 - i + i1]=((180 - this.angle[i])|0);
fullAngle[fullAngle.length - 1 - i  + i1]=((360 - this.angle[i])|0);
}
return fullAngle;
default:
return this.angle;
}
});

Clazz.newMeth(C$, 'get360DegreeRanges$',  function () {
var fullRange=null;
var size=this.range.length;
switch (this.symmetryClass) {
case 1:
fullRange=Clazz.array(Short.TYPE, [2 * size, 2]);
for (var i=0; i < size; i++) {
fullRange[i][0]=this.range[i][0];
fullRange[i][1]=this.range[i][1];
fullRange[size + i][0]=((180 + this.range[i][0])|0);
fullRange[size + i][1]=((180 + this.range[i][1])|0);
}
return fullRange;
case 2:
var i1=(this.angle[0] == 0) ? 1 : 0;
var i2=(this.angle[size - 1] == 180) ? size - 1 : size;
var length=i2 - i1;
fullRange=Clazz.array(Short.TYPE, [size + length, 2]);
for (var i=0; i < size; i++) {
fullRange[i][0]=this.range[i][0];
fullRange[i][1]=this.range[i][1];
}
for (var i=i1; i < i2; i++) {
fullRange[fullRange.length - 1 - i  + i1][0]=((360 - this.range[i][1])|0);
fullRange[fullRange.length - 1 - i  + i1][1]=((360 - this.range[i][0])|0);
}
return fullRange;
case 3:
i1=(this.angle[0] == 0) ? 1 : 0;
i2=(this.angle[size - 1] == 90) ? size - 1 : size;
length=i2 - i1;
fullRange=Clazz.array(Short.TYPE, [2 * size + 2 * length, 2]);
for (var i=0; i < size; i++) {
fullRange[i][0]=this.range[i][0];
fullRange[i][1]=this.range[i][1];
fullRange[size + length + i ][0]=((180 + this.range[i][0])|0);
fullRange[size + length + i ][1]=((180 + this.range[i][1])|0);
}
for (var i=i1; i < i2; i++) {
fullRange[size + length - 1 - i + i1][0]=((180 - this.range[i][1])|0);
fullRange[size + length - 1 - i + i1][1]=((180 - this.range[i][0])|0);
fullRange[fullRange.length - 1 - i  + i1][0]=((360 - this.range[i][1])|0);
fullRange[fullRange.length - 1 - i  + i1][1]=((360 - this.range[i][0])|0);
}
return fullRange;
default:
return this.range;
}
});

Clazz.newMeth(C$, 'get360DegreeFrequencies$',  function () {
var fullFrequency=null;
var size=this.frequency.length;
switch (this.symmetryClass) {
case 1:
fullFrequency=Clazz.array(Short.TYPE, [2 * size]);
for (var i=0; i < size; i++) {
fullFrequency[i]=this.frequency[i];
fullFrequency[size + i]=this.frequency[i];
}
return fullFrequency;
case 2:
var i1=(this.angle[0] == 0) ? 1 : 0;
var i2=(this.angle[size - 1] == 180) ? size - 1 : size;
var length=i2 - i1;
fullFrequency=Clazz.array(Short.TYPE, [size + length]);
for (var i=0; i < size; i++) fullFrequency[i]=this.frequency[i];

for (var i=i1; i < i2; i++) fullFrequency[fullFrequency.length - 1 - i  + i1]=this.frequency[i];

return fullFrequency;
case 3:
i1=(this.angle[0] == 0) ? 1 : 0;
i2=(this.angle[size - 1] == 90) ? size - 1 : size;
length=i2 - i1;
fullFrequency=Clazz.array(Short.TYPE, [2 * size + 2 * length]);
for (var i=0; i < size; i++) {
fullFrequency[i]=this.frequency[i];
fullFrequency[size + length + i ]=this.frequency[i];
}
for (var i=i1; i < i2; i++) {
fullFrequency[size + length - 1 - i + i1]=this.frequency[i];
fullFrequency[fullFrequency.length - 1 - i  + i1]=this.frequency[i];
}
return fullFrequency;
default:
return this.frequency;
}
});

Clazz.newMeth(C$, 'get72BinCounts$',  function () {
if (this.binSize.length == 72) return this.binSize;
var fullBin=Clazz.array(Byte.TYPE, [72]);
switch (this.symmetryClass) {
case 1:
for (var i=0; i < 36; i++) {
fullBin[i]=this.binSize[i];
fullBin[i + 36]=this.binSize[i];
}
break;
case 2:
for (var i=0; i < 36; i++) {
fullBin[i]=this.binSize[i];
fullBin[i + 36]=this.binSize[36 - i];
}
break;
case 3:
for (var i=0; i < 18; i++) {
fullBin[i]=this.binSize[i];
fullBin[i + 18]=this.binSize[18 - i];
fullBin[i + 36]=this.binSize[i];
fullBin[i + 54]=this.binSize[18 - i];
}
break;
}
return fullBin;
});

Clazz.newMeth(C$, 'mergeTorsions$I',  function (mergeSpan) {
var additionalFrequency=0;
while (this.angle.length != 0){
if (this.angle.length == 1) {
if (this.symmetryClass == 1 || this.symmetryClass == 0 ) break;
 else if (this.symmetryClass == 2 && (this.angle[0] == 0 || this.angle[0] == 180 ) ) break;
 else if (this.symmetryClass == 3 && (this.angle[0] == 0 || this.angle[0] == 90 ) ) break;
}var startIndex=(this.angle[0] != 0 && (this.symmetryClass == 2 || this.symmetryClass == 3 ) ) ? -1 : 0;
var minIndex=-1;
var minAngleDif=2147483647;
for (var i1=startIndex; i1 < this.angle.length; i1++) {
var i2=i1 + 1;
var angle1=(i1 >= 0) ? this.angle[i1] : (($s$[0]=-this.angle[0],this.angle[0]=$s$[0],$s$[0]));
var angle2=(i2 < this.angle.length) ? this.angle[i2] : (this.symmetryClass == 1) ? this.angle[0] + 180 : (this.symmetryClass == 2) ? 360 - this.angle[this.angle[i1] == 180 ? i1 - 1 : i1] : (this.symmetryClass == 3) ? 180 - this.angle[this.angle[i1] == 90 ? i1 - 1 : i1] : this.angle[0] + 360;
if (minAngleDif > angle2 - angle1) {
minAngleDif=angle2 - angle1;
minIndex=i1;
}}
if (minAngleDif > mergeSpan) break;
var i1=minIndex;
var i2=i1 + 1;
if (i1 == -1) {
additionalFrequency+=this.frequency[0];
this.angle[0]=(0|0);
this.frequency[0]=(this.frequency[0]*(2)|0);
this.range[0][0]=((($s$[0]=-this.range[0][1],this.range[0][1]=$s$[0],$s$[0]))|0);
} else if (i2 < this.angle.length) {
var mergedAngle=p$2.mergedAngle$I$I$I.apply(this, [i1, i2, this.angle[i2]]);
p$2.mergeAngles$I$I$I$I$I.apply(this, [mergedAngle, i1, i2, this.range[i1][0], this.range[i2][1]]);
} else if (this.symmetryClass == 1) {
i2=0;
var mergedAngle=p$2.mergedAngle$I$I$I.apply(this, [i1, i2, this.angle[i2] + 180]);
if (mergedAngle <= 180) p$2.mergeAngles$I$I$I$I$I.apply(this, [mergedAngle, i1, i2, this.range[i1][0], this.range[i2][1] + 180]);
 else p$2.mergeAngles$I$I$I$I$I.apply(this, [mergedAngle - 180, i2, i1, this.range[i2][0], this.range[i1][1] - 180]);
} else if (this.symmetryClass == 2) {
i2=this.angle[i1] == 180 ? i1 - 1 : i1;
if (this.angle[i1] < 180) {
additionalFrequency+=this.frequency[i1];
this.angle[i1]=(180|0);
this.frequency[i1]=(this.frequency[i1]*(2)|0);
this.range[i1][1]=((360 - this.range[i1][0])|0);
} else {
System.out.println$S("WARNING: TorsionDB - Should have caught the symmetrical situation one peak earlier.");
var mergedAngle=p$2.mergedAngle$I$I$I.apply(this, [i1, i2, this.angle[i2]]);
p$2.mergeAngles$I$I$I$I$I.apply(this, [mergedAngle, i2, i1, this.range[i2][0], this.range[i1][1]]);
}} else if (this.symmetryClass == 3) {
i2=this.angle[i1] == 90 ? i1 - 1 : i1;
if (this.angle[i1] < 90) {
additionalFrequency+=this.frequency[i1];
this.angle[i1]=(90|0);
this.frequency[i1]=(this.frequency[i1]*(2)|0);
this.range[i1][1]=((180 - this.range[i1][0])|0);
} else {
System.out.println$S("WARNING: TorsionDB - Should have caught the symmetrical situation one peak earlier.");
var mergedAngle=p$2.mergedAngle$I$I$I.apply(this, [i1, i2, this.angle[i2]]);
p$2.mergeAngles$I$I$I$I$I.apply(this, [mergedAngle, i2, i1, this.range[i2][0], this.range[i1][1]]);
}} else {
i2=0;
var mergedAngle=p$2.mergedAngle$I$I$I.apply(this, [i1, i2, this.angle[i2] + 360]);
if (mergedAngle <= 360) p$2.mergeAngles$I$I$I$I$I.apply(this, [mergedAngle, i1, i2, this.range[i1][0], this.range[i2][1] + 360]);
 else p$2.mergeAngles$I$I$I$I$I.apply(this, [mergedAngle - 360, i2, i1, this.range[i2][0], this.range[i1][1] - 360]);
}}
if (additionalFrequency != 0) for (var i=0; i < this.frequency.length; i++) this.frequency[i]=(Math.round(100.0 * this.frequency[i] / (100.0 + additionalFrequency))|0);

});

Clazz.newMeth(C$, 'mergedAngle$I$I$I',  function (i1, i2, angle2) {
return Math.round((this.angle[i1] * this.frequency[i1] + angle2 * this.frequency[i2]) / (this.frequency[i1] + this.frequency[i2]));
}, p$2);

Clazz.newMeth(C$, 'mergeAngles$I$I$I$I$I',  function (mergedAngle, iTarget, iDelete, range1, range2) {
this.angle[iTarget]=(mergedAngle|0);
this.frequency[iTarget]=((this.frequency[iTarget] + this.frequency[iDelete])|0);
this.range[iTarget][0]=(range1|0);
this.range[iTarget][1]=(range2|0);
var newSize=this.angle.length - 1;
var newAngle=Clazz.array(Short.TYPE, [newSize]);
var newFrequency=Clazz.array(Short.TYPE, [newSize]);
var newRange=Clazz.array(Short.TYPE, [newSize, null]);
var iNew=0;
for (var i=0; i < this.angle.length; i++) {
if (i != iDelete) {
newAngle[iNew]=this.angle[i];
newFrequency[iNew]=this.frequency[i];
newRange[iNew]=this.range[i];
++iNew;
}}
this.angle=newAngle;
this.frequency=newFrequency;
this.range=newRange;
}, p$2);
var $s$ = new Int16Array(1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:19 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
