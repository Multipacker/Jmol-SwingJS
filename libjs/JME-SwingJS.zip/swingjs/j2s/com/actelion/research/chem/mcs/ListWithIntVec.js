(function(){var P$=Clazz.newPackage("com.actelion.research.chem.mcs"),I$=[[0,'com.actelion.research.util.datamodel.IntVec','com.actelion.research.util.datamodel.IntArray','StringBuilder','java.util.ArrayList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ListWithIntVec");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['positionInContainer'],'O',['iv','com.actelion.research.util.datamodel.IntVec','arr','com.actelion.research.util.datamodel.IntArray']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I',  function (size) {
C$.c$$I$I.apply(this, [size, -1]);
}, 1);

Clazz.newMeth(C$, 'c$$I$I',  function (size, positionInContainer) {
;C$.$init$.apply(this);
this.iv=Clazz.new_($I$(1,1).c$$I,[size]);
this.arr=Clazz.new_($I$(2,1));
this.positionInContainer=positionInContainer;
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_mcs_ListWithIntVec',  function (liv) {
;C$.$init$.apply(this);
this.iv=Clazz.new_($I$(1,1).c$$com_actelion_research_util_datamodel_IntVec,[liv.iv]);
this.arr=Clazz.new_($I$(2,1).c$$com_actelion_research_util_datamodel_IntArray,[liv.arr]);
}, 1);

Clazz.newMeth(C$, 'copyIntoThis$com_actelion_research_chem_mcs_ListWithIntVec',  function (liv) {
this.iv.set$I(0);
System.arraycopy$O$I$O$I$I(liv.iv.get$(), 0, this.iv.get$(), 0, this.iv.get$().length);
this.arr.reset$();
for (var i=0; i < liv.arr.length$(); i++) {
this.arr.add$I(liv.arr.get$I(i));
}
});

Clazz.newMeth(C$, 'addBit$I',  function (index) {
if (this.iv.isBitSet$I(index)) {
return false;
}this.iv.setBit$I(index);
this.arr.add$I(index);
return true;
});

Clazz.newMeth(C$, 'addAllBits$com_actelion_research_chem_mcs_ListWithIntVec',  function (liv) {
var size=liv.size$();
for (var i=0; i < size; i++) {
this.addBit$I(liv.get$I(i));
}
this.calculateHash$();
});

Clazz.newMeth(C$, 'isOverlap$com_actelion_research_chem_mcs_ListWithIntVec',  function (liv) {
var overlap=false;
var size=liv.size$();
for (var i=0; i < size; i++) {
if (this.isBitSet$I(liv.get$I(i))) {
overlap=true;
break;
}}
return overlap;
});

Clazz.newMeth(C$, 'equals$O',  function (o) {
var iv2=(o).iv;
return this.iv.equals$O(iv2);
});

Clazz.newMeth(C$, 'isBitSet$I',  function (index) {
return this.iv.isBitSet$I(index);
});

Clazz.newMeth(C$, 'getBitsSet$',  function () {
return this.iv.getBitsSet$();
});

Clazz.newMeth(C$, 'sizeBits$',  function () {
return this.iv.sizeBits$();
});

Clazz.newMeth(C$, 'calculateHash$',  function () {
this.iv.calculateHashCode$();
});

Clazz.newMeth(C$, 'hashCode$',  function () {
return this.iv.hashCode$();
});

Clazz.newMeth(C$, 'get$I',  function (index) {
return this.arr.get$I(index);
});

Clazz.newMeth(C$, 'size$',  function () {
return this.arr.length$();
});

Clazz.newMeth(C$, 'getLengthIntVec$',  function () {
return this.iv.size$();
});

Clazz.newMeth(C$, 'reset$',  function () {
this.iv.set$I(0);
this.arr.reset$();
});

Clazz.newMeth(C$, 'toStringArray$',  function () {
var sb=Clazz.new_($I$(3,1));
for (var i=0; i < this.arr.length$(); i++) {
sb.append$I(this.arr.get$I(i));
if (i < this.arr.length$() - 1) {
sb.append$S(" ");
}}
return sb.toString();
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(3,1));
var si=this.iv.sizeBits$();
var li=Clazz.new_($I$(4,1));
for (var i=0; i < si; i++) {
if (this.iv.isBitSet$I(i)) li.add$O(Integer.valueOf$I(i));
}
for (var i=0; i < li.size$(); i++) {
sb.append$O(li.get$I(i));
if (i < li.size$() - 1) {
sb.append$S(", ");
}}
return sb.toString();
});

Clazz.newMeth(C$, 'getPositionInContainer$',  function () {
return this.positionInContainer;
});

Clazz.newMeth(C$, 'read$java_io_InputStream',  function (s) {
var positionInContainer=$I$(2).parseInteger$java_io_InputStream(s);
var iv=$I$(1).read$java_io_InputStream(s);
var ia=$I$(2).read$java_io_InputStream(s);
var liv=Clazz.new_(C$);
liv.positionInContainer=positionInContainer;
liv.iv=iv;
liv.arr=ia;
return liv;
}, 1);

Clazz.newMeth(C$, 'write2String$',  function () {
var sb=Clazz.new_($I$(3,1));
sb.append$I(this.positionInContainer);
sb.append$S(" ");
sb.append$S(this.iv.write2String$());
sb.append$S(" ");
sb.append$S(this.arr.write2String$());
return sb.toString();
});
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:26 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
