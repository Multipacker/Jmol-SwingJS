(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor"),I$=[[0,'com.actelion.research.chem.descriptor.DescriptorInfo']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*i*/var C$=Clazz.newInterface(P$, "DescriptorConstants");

C$.$fields$=[[]
,['I',['DESCRIPTOR_TYPE_UNKNOWN','DESCRIPTOR_TYPE_MOLECULE','DESCRIPTOR_TYPE_REACTION'],'O',['DESCRIPTOR_FFP512','com.actelion.research.chem.descriptor.DescriptorInfo','+DESCRIPTOR_SSSFP','+DESCRIPTOR_PFP512','+DESCRIPTOR_HashedCFp','+DESCRIPTOR_SkeletonSpheres','+DESCRIPTOR_ALLFRAG','+DESCRIPTOR_OrganicFunctionalGroups','+DESCRIPTOR_CenteredSkeletonFragments','+DESCRIPTOR_TopoPPHistDist','+DESCRIPTOR_Flexophore','+DESCRIPTOR_ShapeAlign','+DESCRIPTOR_ShapeAlignSingleConf','+DESCRIPTOR_ReactionFP','+DESCRIPTOR_IntegerVector','+DESCRIPTOR_MAX_COMMON_SUBSTRUCT','+DESCRIPTOR_SUBSTRUCT_QUERY_IN_BASE','+DESCRIPTOR_FULL_FRAGMENT_SET','+DESCRIPTOR_PhysicoChemicalProperties','+DESCRIPTOR_BINARY_SKELETONSPHERES','+DESCRIPTOR_PTREE','DESCRIPTOR_LIST','com.actelion.research.chem.descriptor.DescriptorInfo[]','+DESCRIPTOR_EXTENDED_LIST']]]

C$.$static$=function(){C$.$static$=0;
C$.DESCRIPTOR_TYPE_UNKNOWN=-1;
C$.DESCRIPTOR_TYPE_MOLECULE=1;
C$.DESCRIPTOR_TYPE_REACTION=2;
C$.DESCRIPTOR_FFP512=Clazz.new_($I$(1,1).c$$S$S$S$I$Z$Z$Z$Z,["FragmentFingerprint512", "FragFp", "1.2.1", 1, true, true, true, false]);
C$.DESCRIPTOR_SSSFP=Clazz.new_($I$(1,1).c$$S$S$S$I$Z$Z$Z$Z,["SSSPathFingerprint", "SSSPathFp", "1.0", 1, true, true, true, false]);
C$.DESCRIPTOR_PFP512=Clazz.new_($I$(1,1).c$$S$S$S$I$Z$Z$Z$Z,["PathFingerprint512", "PathFp", "1.1", 1, true, true, true, false]);
C$.DESCRIPTOR_HashedCFp=Clazz.new_($I$(1,1).c$$S$S$S$I$Z$Z$Z$Z,["HashedSphericalFingerprint512", "SphereFp", "2.1", 1, true, true, true, true]);
C$.DESCRIPTOR_SkeletonSpheres=Clazz.new_($I$(1,1).c$$S$S$S$I$Z$Z$Z$Z,["HashedSkeletonSphereCount1024", "SkelSpheres", "1.1", 1, false, true, true, true]);
C$.DESCRIPTOR_ALLFRAG=Clazz.new_($I$(1,1).c$$S$S$S$I$Z$Z$Z$Z,["AllFragments1024", "AllFragFp", "1.0", 1, true, true, true, false]);
C$.DESCRIPTOR_OrganicFunctionalGroups=Clazz.new_($I$(1,1).c$$S$S$S$I$Z$Z$Z$Z,["FunctionalGroupTreeCount1024", "OrgFunctions", "1.0", 1, false, false, false, true]);
C$.DESCRIPTOR_CenteredSkeletonFragments=Clazz.new_($I$(1,1).c$$S$S$S$I$Z$Z$Z$Z,["CenteredSkeletonFragments", "CentSkelFrags", "1.0", 1, false, false, true, true]);
C$.DESCRIPTOR_TopoPPHistDist=Clazz.new_($I$(1,1).c$$S$S$S$I$Z$Z$Z$Z,["TopologicalPharmacophoreHistograms", "TopPPHist", "version", 1, false, false, false, false]);
C$.DESCRIPTOR_Flexophore=Clazz.new_($I$(1,1).c$$S$S$S$I$Z$Z$Z$Z,["Flexophore", "Flexophore", "5.0", 1, false, false, false, false]);
C$.DESCRIPTOR_ShapeAlign=Clazz.new_($I$(1,1).c$$S$S$S$I$Z$Z$Z$Z,["PharmacophoreEnhancedShapeAlignment", "PheSA", "2.1", 1, false, false, false, false]);
C$.DESCRIPTOR_ShapeAlignSingleConf=Clazz.new_($I$(1,1).c$$S$S$S$I$Z$Z$Z$Z,["PharmacophoreEnhancedShapeAlignmentSingleConfQuery", "PheSASingleConf", "2.1", 1, false, false, false, false]);
C$.DESCRIPTOR_ReactionFP=Clazz.new_($I$(1,1).c$$S$S$S$I$Z$Z$Z$Z,["ReactionFingerprint", "RxnFP", "1.0.0", 2, false, false, false, false]);
C$.DESCRIPTOR_IntegerVector=Clazz.new_($I$(1,1).c$$S$S$S$I$Z$Z$Z$Z,["IntegerVector", "IntVec", "1.0", -1, false, true, false, false]);
C$.DESCRIPTOR_MAX_COMMON_SUBSTRUCT=Clazz.new_($I$(1,1).c$$S$S$S$I$Z$Z$Z$Z,["MaximumCommonSubstructure", "Structure", "1.0", 1, false, false, true, false]);
C$.DESCRIPTOR_SUBSTRUCT_QUERY_IN_BASE=Clazz.new_($I$(1,1).c$$S$S$S$I$Z$Z$Z$Z,["SubStructureQueryInBase", "SSSQinB", "1.0", 1, false, false, false, false]);
C$.DESCRIPTOR_FULL_FRAGMENT_SET=Clazz.new_($I$(1,1).c$$S$S$S$I$Z$Z$Z$Z,["FullFragmentSet", "FullFragSet", "1.0", 1, true, true, true, false]);
C$.DESCRIPTOR_PhysicoChemicalProperties=Clazz.new_($I$(1,1).c$$S$S$S$I$Z$Z$Z$Z,["DescriptorPhysicoChemicalProperties", "PhysChem", "version", 1, false, true, false, false]);
C$.DESCRIPTOR_BINARY_SKELETONSPHERES=Clazz.new_($I$(1,1).c$$S$S$S$I$Z$Z$Z$Z,["BinarySkeletonSpheres", "BinSkelSpheres", "10052017", 1, true, true, true, false]);
C$.DESCRIPTOR_PTREE=Clazz.new_($I$(1,1).c$$S$S$S$I$Z$Z$Z$Z,["PharmacophoreTree", "PTree", "1.0", 1, false, false, false, false]);
C$.DESCRIPTOR_LIST=Clazz.array($I$(1), -1, [C$.DESCRIPTOR_FFP512, C$.DESCRIPTOR_PFP512, C$.DESCRIPTOR_ALLFRAG, C$.DESCRIPTOR_HashedCFp, C$.DESCRIPTOR_SkeletonSpheres, C$.DESCRIPTOR_OrganicFunctionalGroups, C$.DESCRIPTOR_Flexophore, C$.DESCRIPTOR_ReactionFP]);
C$.DESCRIPTOR_EXTENDED_LIST=Clazz.array($I$(1), -1, [C$.DESCRIPTOR_FFP512, C$.DESCRIPTOR_PFP512, C$.DESCRIPTOR_SSSFP, C$.DESCRIPTOR_ALLFRAG, C$.DESCRIPTOR_HashedCFp, C$.DESCRIPTOR_SkeletonSpheres, C$.DESCRIPTOR_BINARY_SKELETONSPHERES, C$.DESCRIPTOR_CenteredSkeletonFragments, C$.DESCRIPTOR_MAX_COMMON_SUBSTRUCT, C$.DESCRIPTOR_SUBSTRUCT_QUERY_IN_BASE, C$.DESCRIPTOR_TopoPPHistDist, C$.DESCRIPTOR_OrganicFunctionalGroups, C$.DESCRIPTOR_Flexophore, C$.DESCRIPTOR_ShapeAlign, C$.DESCRIPTOR_ReactionFP, C$.DESCRIPTOR_IntegerVector, C$.DESCRIPTOR_FULL_FRAGMENT_SET, C$.DESCRIPTOR_PhysicoChemicalProperties, C$.DESCRIPTOR_BINARY_SKELETONSPHERES]);
};
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:20 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
