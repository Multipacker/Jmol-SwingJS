(function(){var P$=Clazz.newPackage("com.actelion.research.chem.mcs"),p$1={},I$=[[0,'java.util.HashSet','java.util.ArrayList','com.actelion.research.chem.SSSearcher',['com.actelion.research.chem.mcs.MCSFast','.ComparatorBitsSet'],'java.util.HashMap','com.actelion.research.util.datamodel.IntVec','java.util.Collections','com.actelion.research.chem.ExtendedMoleculeFunctions','com.actelion.research.chem.StereoMolecule','com.actelion.research.calc.ArrayUtilsCalc']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MCSFast", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['ComparatorBitsSet',10]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['considerAromaticRings','considerRings'],'O',['mol','com.actelion.research.chem.StereoMolecule','+frag','hsIndexFragCandidates','java.util.HashSet','+hsIndexFragGarbage','+hsIndexFragSolution','sss','com.actelion.research.chem.SSSearcher','comparatorBitsSet','com.actelion.research.chem.mcs.MCSFast.ComparatorBitsSet','molMCS','com.actelion.research.chem.StereoMolecule','liMCSSolutions','java.util.List','hmRingBnd_ListRingBnds','java.util.HashMap','+hmAromaticRingBnd_ListRingBnds','ringCollection','com.actelion.research.chem.RingCollection']]]

Clazz.newMeth(C$, 'c$',  function () {
C$.c$$I.apply(this, [0]);
}, 1);

Clazz.newMeth(C$, 'c$$I',  function (ringStatus) {
;C$.$init$.apply(this);
this.considerRings=false;
this.considerAromaticRings=false;
switch (ringStatus) {
case 0:
break;
case 1:
this.considerRings=true;
break;
case 2:
this.considerAromaticRings=true;
break;
default:
break;
}
this.hsIndexFragCandidates=Clazz.new_($I$(1,1).c$$I,[1200]);
this.hsIndexFragGarbage=Clazz.new_($I$(1,1).c$$I,[1200]);
this.hsIndexFragSolution=Clazz.new_($I$(1,1).c$$I,[1200]);
this.liMCSSolutions=Clazz.new_($I$(2,1).c$$I,[1200]);
this.sss=Clazz.new_($I$(3,1));
this.comparatorBitsSet=Clazz.new_($I$(4,1));
this.hmRingBnd_ListRingBnds=Clazz.new_($I$(5,1));
this.hmAromaticRingBnd_ListRingBnds=Clazz.new_($I$(5,1));
}, 1);

Clazz.newMeth(C$, 'set$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule',  function (mol, frag) {
this.mol=mol;
this.frag=frag;
p$1.init.apply(this, []);
});

Clazz.newMeth(C$, 'init',  function () {
this.hsIndexFragCandidates.clear$();
this.hsIndexFragGarbage.clear$();
this.hsIndexFragSolution.clear$();
this.liMCSSolutions.clear$();
this.hmRingBnd_ListRingBnds.clear$();
this.hmAromaticRingBnd_ListRingBnds.clear$();
p$1.initCandidates.apply(this, []);
}, p$1);

Clazz.newMeth(C$, 'initCandidates',  function () {
this.ringCollection=this.frag.getRingSet$();
var rings=this.ringCollection.getSize$();
for (var i=0; i < rings; i++) {
var arrIndexBnd=this.ringCollection.getRingBonds$I(i);
for (var j=0; j < arrIndexBnd.length; j++) {
if (!this.hmRingBnd_ListRingBnds.containsKey$O(Integer.valueOf$I(arrIndexBnd[j]))) {
this.hmRingBnd_ListRingBnds.put$O$O(Integer.valueOf$I(arrIndexBnd[j]), Clazz.new_($I$(2,1)));
}var li=this.hmRingBnd_ListRingBnds.get$O(Integer.valueOf$I(arrIndexBnd[j]));
li.add$O(arrIndexBnd);
}
if (this.ringCollection.isAromatic$I(i)) {
for (var j=0; j < arrIndexBnd.length; j++) {
if (!this.hmAromaticRingBnd_ListRingBnds.containsKey$O(Integer.valueOf$I(arrIndexBnd[j]))) {
this.hmAromaticRingBnd_ListRingBnds.put$O$O(Integer.valueOf$I(arrIndexBnd[j]), Clazz.new_($I$(2,1)));
}var li=this.hmAromaticRingBnd_ListRingBnds.get$O(Integer.valueOf$I(arrIndexBnd[j]));
li.add$O(arrIndexBnd);
}
}}
var nInts=(((this.frag.getBonds$() / 32) + (0.96875))|0);
for (var i=0; i < this.frag.getBonds$(); i++) {
var iv=Clazz.new_($I$(6,1).c$$I,[nInts]);
p$1.setBitAndAddRelatedRingBonds$I$com_actelion_research_util_datamodel_IntVec.apply(this, [i, iv]);
this.hsIndexFragCandidates.add$O(iv);
}
}, p$1);

Clazz.newMeth(C$, 'setBitAndAddRelatedRingBonds$I$com_actelion_research_util_datamodel_IntVec',  function (bit, iv) {
if (!this.considerAromaticRings && !this.considerRings ) {
iv.setBit$I(bit);
} else if (this.considerRings) {
iv.setBit$I(bit);
if (this.hmRingBnd_ListRingBnds.containsKey$O(Integer.valueOf$I(bit))) {
var li=this.hmRingBnd_ListRingBnds.get$O(Integer.valueOf$I(bit));
for (var i=0; i < li.size$(); i++) {
var a=li.get$I(i);
for (var j=0; j < a.length; j++) {
iv.setBit$I(a[j]);
}
}
}} else if (this.considerAromaticRings) {
iv.setBit$I(bit);
if (this.hmAromaticRingBnd_ListRingBnds.containsKey$O(Integer.valueOf$I(bit))) {
var li=this.hmAromaticRingBnd_ListRingBnds.get$O(Integer.valueOf$I(bit));
for (var i=0; i < li.size$(); i++) {
var a=li.get$I(i);
for (var j=0; j < a.length; j++) {
iv.setBit$I(a[j]);
}
}
}}iv.calculateHashCode$();
}, p$1);

Clazz.newMeth(C$, 'getAllSolutionsForCommonSubstructures',  function () {
this.sss.setMolecule$com_actelion_research_chem_StereoMolecule(this.mol);
this.frag.setFragment$Z(true);
this.sss.setFragment$com_actelion_research_chem_StereoMolecule(this.frag);
try {
if (this.sss.findFragmentInMolecule$() > 0) {
this.molMCS=this.frag;
var liIndexFragCandidates=Clazz.new_($I$(2,1).c$$java_util_Collection,[this.hsIndexFragCandidates]);
var iv=liIndexFragCandidates.get$I(0);
iv.setBits$I$I(0, iv.sizeBits$());
iv.calculateHashCode$();
var li=Clazz.new_($I$(2,1));
li.add$O(iv);
return li;
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
var maxSizeCandidates=0;
while (!this.hsIndexFragCandidates.isEmpty$()){
var liIndexFragCandidates=Clazz.new_($I$(2,1).c$$java_util_Collection,[this.hsIndexFragCandidates]);
$I$(7).sort$java_util_List$java_util_Comparator(liIndexFragCandidates, this.comparatorBitsSet);
var iv=liIndexFragCandidates.get$I(liIndexFragCandidates.size$() - 1);
this.hsIndexFragCandidates.remove$O(iv);
if (false) {
System.out.println$S("Bits set " + iv.getBitsSet$());
if (iv.getBitsSet$() == this.frag.getBonds$()) {
System.out.println$S("Full structure in iv.");
}}var fragSub=C$.getSubFrag$com_actelion_research_chem_StereoMolecule$com_actelion_research_util_datamodel_IntVec(this.frag, iv);
this.sss.setFragment$com_actelion_research_chem_StereoMolecule(fragSub);
if (this.sss.findFragmentInMolecule$() > 0) {
this.hsIndexFragSolution.add$O(iv);
p$1.removeAllSubSolutions$com_actelion_research_util_datamodel_IntVec.apply(this, [iv]);
if (iv.getBitsSet$() != this.frag.getBonds$()) {
var liIV=p$1.getAllPlusOneAtomCombinations$com_actelion_research_util_datamodel_IntVec$com_actelion_research_chem_StereoMolecule.apply(this, [iv, this.frag]);
for (var ivPlus, $ivPlus = liIV.iterator$(); $ivPlus.hasNext$()&&((ivPlus=($ivPlus.next$())),1);) {
if (false) {
if (ivPlus.getBitsSet$() == this.frag.getBonds$()) {
System.out.println$S("Full structure in ivPlus.");
}}if ((!this.hsIndexFragGarbage.contains$O(ivPlus)) && (!this.hsIndexFragSolution.contains$O(ivPlus)) ) {
this.hsIndexFragCandidates.add$O(ivPlus);
}}
if (false) System.out.println$S("tsIndexFragCandidates " + this.hsIndexFragCandidates.size$());
}if (maxSizeCandidates < this.hsIndexFragCandidates.size$()) maxSizeCandidates=this.hsIndexFragCandidates.size$();
} else {
this.hsIndexFragGarbage.add$O(iv);
}}
if (this.hsIndexFragSolution.size$() == 0) {
return null;
}return C$.getFinalSolutionSet$java_util_HashSet(this.hsIndexFragSolution);
}, p$1);

Clazz.newMeth(C$, 'getAllCommonSubstructures$',  function () {
var liIndexFragSolution=p$1.getAllSolutionsForCommonSubstructures.apply(this, []);
if (liIndexFragSolution == null ) {
return null;
}$I$(7).sort$java_util_List$java_util_Comparator(liIndexFragSolution, this.comparatorBitsSet);
var ivMCS=liIndexFragSolution.get$I(liIndexFragSolution.size$() - 1);
this.molMCS=C$.getSubFrag$com_actelion_research_chem_StereoMolecule$com_actelion_research_util_datamodel_IntVec(this.frag, ivMCS);
var li=Clazz.new_($I$(2,1));
for (var iv, $iv = liIndexFragSolution.iterator$(); $iv.hasNext$()&&((iv=($iv.next$())),1);) {
li.add$O(C$.getSubFrag$com_actelion_research_chem_StereoMolecule$com_actelion_research_util_datamodel_IntVec(this.frag, iv));
}
return $I$(8).removeSubStructures$java_util_List(li);
});

Clazz.newMeth(C$, 'getMCS$',  function () {
var liIndexFragSolution=p$1.getAllSolutionsForCommonSubstructures.apply(this, []);
if (liIndexFragSolution == null ) {
return null;
}$I$(7).sort$java_util_List$java_util_Comparator(liIndexFragSolution, this.comparatorBitsSet);
var ivMCS=liIndexFragSolution.get$I(liIndexFragSolution.size$() - 1);
this.molMCS=C$.getSubFrag$com_actelion_research_chem_StereoMolecule$com_actelion_research_util_datamodel_IntVec(this.frag, ivMCS);
return this.molMCS;
});

Clazz.newMeth(C$, 'getSubFrag$com_actelion_research_chem_StereoMolecule$com_actelion_research_util_datamodel_IntVec',  function (frag, iv) {
var bonds=frag.getBonds$();
var hsAtomIndex=Clazz.new_($I$(1,1));
for (var i=0; i < bonds; i++) {
if (iv.isBitSet$I(i)) {
var indexAtom1=frag.getBondAtom$I$I(0, i);
var indexAtom2=frag.getBondAtom$I$I(1, i);
hsAtomIndex.add$O(Integer.valueOf$I(indexAtom1));
hsAtomIndex.add$O(Integer.valueOf$I(indexAtom2));
}}
var fragSubBonds=Clazz.new_([hsAtomIndex.size$(), bonds],$I$(9,1).c$$I$I);
fragSubBonds.setFragment$Z(true);
var arrMapAtom=Clazz.array(Integer.TYPE, [frag.getAtoms$()]);
$I$(10).set$IA$I(arrMapAtom, -1);
for (var indexAtom, $indexAtom = hsAtomIndex.iterator$(); $indexAtom.hasNext$()&&((indexAtom=($indexAtom.next$()).intValue$()),1);) {
var indexAtomNew=fragSubBonds.addAtom$I(frag.getAtomicNo$I(indexAtom));
fragSubBonds.setAtomX$I$D(indexAtomNew, frag.getAtomX$I(indexAtom));
fragSubBonds.setAtomY$I$D(indexAtomNew, frag.getAtomY$I(indexAtom));
fragSubBonds.setAtomZ$I$D(indexAtomNew, frag.getAtomZ$I(indexAtom));
arrMapAtom[indexAtom]=indexAtomNew;
}
for (var i=0; i < bonds; i++) {
if (iv.isBitSet$I(i)) {
var indexAtom1=frag.getBondAtom$I$I(0, i);
var indexAtom2=frag.getBondAtom$I$I(1, i);
var indexAtomNew1=arrMapAtom[indexAtom1];
var indexAtomNew2=arrMapAtom[indexAtom2];
var type=frag.getBondType$I(i);
if (frag.isDelocalizedBond$I(i)) {
type=64;
}fragSubBonds.addBond$I$I$I(indexAtomNew1, indexAtomNew2, type);
}}
fragSubBonds.ensureHelperArrays$I(7);
return fragSubBonds;
}, 1);

Clazz.newMeth(C$, 'getAllPlusOneAtomCombinations$com_actelion_research_util_datamodel_IntVec$com_actelion_research_chem_StereoMolecule',  function (iv, frag) {
var bonds=frag.getBonds$();
var liIntVec=Clazz.new_($I$(2,1));
var hsAtomIndex=Clazz.new_($I$(1,1));
for (var i=0; i < bonds; i++) {
if (iv.isBitSet$I(i)) {
var indexAt1=frag.getBondAtom$I$I(0, i);
var indexAt2=frag.getBondAtom$I$I(1, i);
hsAtomIndex.add$O(Integer.valueOf$I(indexAt1));
hsAtomIndex.add$O(Integer.valueOf$I(indexAt2));
}}
for (var i=0; i < bonds; i++) {
if (!iv.isBitSet$I(i)) {
var indexAt1=frag.getBondAtom$I$I(0, i);
var indexAt2=frag.getBondAtom$I$I(1, i);
if (hsAtomIndex.contains$O(Integer.valueOf$I(indexAt1)) || hsAtomIndex.contains$O(Integer.valueOf$I(indexAt2)) ) {
var ivPlus=Clazz.new_([iv.get$()],$I$(6,1).c$$IA);
p$1.setBitAndAddRelatedRingBonds$I$com_actelion_research_util_datamodel_IntVec.apply(this, [i, ivPlus]);
liIntVec.add$O(ivPlus);
}}}
return liIntVec;
}, p$1);

Clazz.newMeth(C$, 'removeAllSubSolutions$com_actelion_research_util_datamodel_IntVec',  function (ivSolution) {
var liIndexFragSolution=Clazz.new_($I$(2,1).c$$java_util_Collection,[this.hsIndexFragCandidates]);
for (var ivCandidate, $ivCandidate = liIndexFragSolution.iterator$(); $ivCandidate.hasNext$()&&((ivCandidate=($ivCandidate.next$())),1);) {
if (C$.isCandidateInSolution$com_actelion_research_util_datamodel_IntVec$com_actelion_research_util_datamodel_IntVec(ivSolution, ivCandidate)) {
this.hsIndexFragCandidates.remove$O(ivCandidate);
}}
}, p$1);

Clazz.newMeth(C$, 'getFinalSolutionSet$java_util_HashSet',  function (hsIndexFragSolution) {
var liIndexFragSolution=Clazz.new_($I$(2,1).c$$java_util_Collection,[hsIndexFragSolution]);
for (var i=liIndexFragSolution.size$() - 1; i >= 0; i--) {
var ivCandidate=liIndexFragSolution.get$I(i);
for (var j=0; j < liIndexFragSolution.size$(); j++) {
var ivSolution=liIndexFragSolution.get$I(j);
if (i != j) {
if (C$.isCandidateInSolution$com_actelion_research_util_datamodel_IntVec$com_actelion_research_util_datamodel_IntVec(ivSolution, ivCandidate)) {
liIndexFragSolution.remove$I(i);
break;
}}}
}
return liIndexFragSolution;
}, 1);

Clazz.newMeth(C$, 'isCandidateInSolution$com_actelion_research_util_datamodel_IntVec$com_actelion_research_util_datamodel_IntVec',  function (ivSolution, ivCandidate) {
var iv=$I$(6).OR$com_actelion_research_util_datamodel_IntVec$com_actelion_research_util_datamodel_IntVec(ivSolution, ivCandidate);
if (iv.equals$O(ivSolution)) {
return true;
}return false;
}, 1);

Clazz.newMeth(C$, 'getScore$',  function () {
var sc=0;
var nAtmsFrag=this.frag.getBonds$();
var nAtmsMol=this.mol.getBonds$();
var nAtmsMCS=this.molMCS.getBonds$();
sc=nAtmsMCS / Math.max(nAtmsFrag, nAtmsMol);
return sc;
});

Clazz.newMeth(C$, 'isConsiderAromaticRings$',  function () {
return this.considerAromaticRings;
});

Clazz.newMeth(C$, 'isConsiderRings$',  function () {
return this.considerRings;
});
;
(function(){/*c*/var C$=Clazz.newClass(P$.MCSFast, "ComparatorBitsSet", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, 'java.util.Comparator');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, ['compare$com_actelion_research_util_datamodel_IntVec$com_actelion_research_util_datamodel_IntVec','compare$O$O'],  function (iv1, iv2) {
var bits1=iv1.getBitsSet$();
var bits2=iv2.getBitsSet$();
if (bits1 > bits2) {
return 1;
} else if (bits1 < bits2) {
return -1;
}return 0;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:27 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
