(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore"),I$=[[0,'StringBuilder','com.actelion.research.util.Formatter']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PPNodeVizTriangle", null, null, 'Comparable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['area'],'O',['n1','com.actelion.research.chem.descriptor.flexophore.PPNodeViz','+n2','+n3']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_descriptor_flexophore_PPNodeViz$com_actelion_research_chem_descriptor_flexophore_PPNodeViz$com_actelion_research_chem_descriptor_flexophore_PPNodeViz',  function (n1, n2, n3) {
;C$.$init$.apply(this);
this.n1=n1;
this.n2=n2;
this.n3=n3;
this.area=-1;
}, 1);

Clazz.newMeth(C$, 'getArea$',  function () {
return this.area;
});

Clazz.newMeth(C$, 'setArea$D',  function (area) {
this.area=area;
});

Clazz.newMeth(C$, ['compareTo$com_actelion_research_chem_descriptor_flexophore_PPNodeVizTriangle','compareTo$O'],  function (ta) {
if (this.area > ta.area ) {
return 1;
}if (this.area < ta.area ) {
return -1;
}if (this.area == ta.area ) {
return 0;
}return 0;
});

Clazz.newMeth(C$, 'getNodeA$',  function () {
return this.n1;
});

Clazz.newMeth(C$, 'getNodeB$',  function () {
return this.n2;
});

Clazz.newMeth(C$, 'getNodeC$',  function () {
return this.n3;
});

Clazz.newMeth(C$, 'getCoordinatesA$',  function () {
return this.n1.getCoordinates$();
});

Clazz.newMeth(C$, 'getCoordinatesB$',  function () {
return this.n2.getCoordinates$();
});

Clazz.newMeth(C$, 'getCoordinatesC$',  function () {
return this.n3.getCoordinates$();
});

Clazz.newMeth(C$, 'toString',  function () {
var builder=Clazz.new_($I$(1,1));
builder.append$S("area=");
builder.append$S($I$(2,"format3$Double",[Double.valueOf$D(this.area)]));
return builder.toString();
});

Clazz.newMeth(C$, 'getComparatorArea$',  function () {
var comp=((P$.PPNodeVizTriangle$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "PPNodeVizTriangle$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, ['compare$com_actelion_research_chem_descriptor_flexophore_PPNodeVizTriangle$com_actelion_research_chem_descriptor_flexophore_PPNodeVizTriangle','compare$O$O'],  function (ta1, ta2) {
if (ta1.area > ta2.area ) {
return 1;
}if (ta1.area < ta2.area ) {
return -1;
}return 0;
});
})()
), Clazz.new_(P$.PPNodeVizTriangle$1.$init$,[this, null]));
return comp;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:22 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
