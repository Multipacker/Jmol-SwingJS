(function(){var P$=Clazz.newPackage("com.actelion.research.chem.mmp"),p$1={},I$=[[0,'com.actelion.research.chem.MolecularFormula','com.actelion.research.util.DoubleFormat','com.actelion.research.chem.prediction.CLogPPredictor','com.actelion.research.chem.prediction.PolarSurfaceAreaPredictor','com.actelion.research.chem.conf.MolecularFlexibilityCalculator','com.actelion.research.chem.AtomFunctionAnalyzer','com.actelion.research.chem.StereoMolecule','java.util.TreeSet','com.actelion.research.chem.Canonizer']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MMPPropertyCalculator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['calculatedPropertyAttributeIndex'],'S',['propertyName','shortDisplayedPropertyName','longDisplayedPropertyName','value']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'CalculateCompound$S$com_actelion_research_chem_StereoMolecule$I',  function (propertyName, mol, calculatedPropertyAttributeIndex) {
this.propertyName=propertyName;
this.calculatedPropertyAttributeIndex=calculatedPropertyAttributeIndex;
this.value=null;
if (propertyName.toLowerCase$().equals$O("total_weight") || propertyName.toLowerCase$().equals$O("mw") ) {
this.shortDisplayedPropertyName="MW";
this.longDisplayedPropertyName="Molecular Weight";
var totalWeight=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_ExtendedMolecule,[mol]).getRelativeWeight$();
this.value=$I$(2).toString$D$I$Z(totalWeight, 6, true);
} else if (propertyName.toLowerCase$().equals$O("logp")) {
this.shortDisplayedPropertyName="LogP";
this.longDisplayedPropertyName="LogP";
var predictor=Clazz.new_($I$(3,1));
var cLogP=predictor.assessCLogP$com_actelion_research_chem_StereoMolecule(mol);
this.value=Float.toString$F(cLogP);
} else if (propertyName.toLowerCase$().equals$O("acceptors")) {
this.shortDisplayedPropertyName="Acceptors";
this.longDisplayedPropertyName="Acceptors";
var count=0;
for (var atom=0; atom < mol.getAllAtoms$(); atom++) if (mol.getAtomicNo$I(atom) == 7 || mol.getAtomicNo$I(atom) == 8 ) ++count;

this.value="" + count;
} else if (propertyName.toLowerCase$().equals$O("donors")) {
this.shortDisplayedPropertyName="Donors";
this.longDisplayedPropertyName="Donors";
var count=0;
for (var atom=0; atom < mol.getAllAtoms$(); atom++) if ((mol.getAtomicNo$I(atom) == 7 || mol.getAtomicNo$I(atom) == 8 ) && mol.getAllHydrogens$I(atom) > 0 ) ++count;

this.value="" + count;
} else if (propertyName.toLowerCase$().equals$O("psa")) {
this.shortDisplayedPropertyName="PSA";
this.longDisplayedPropertyName="Polar Surface Area";
var predictor=Clazz.new_($I$(4,1));
var psa=predictor.assessPSA$com_actelion_research_chem_StereoMolecule(mol);
this.value=Float.toString$F(psa);
} else if (propertyName.toLowerCase$().equals$O("shape")) {
this.shortDisplayedPropertyName="Shape";
this.longDisplayedPropertyName="Shape";
this.value=$I$(2,"toString$D",[p$1.assessMolecularShape$com_actelion_research_chem_StereoMolecule.apply(this, [mol])]);
} else if (propertyName.toLowerCase$().equals$O("flexibility")) {
this.shortDisplayedPropertyName="Flexibility";
this.longDisplayedPropertyName="Flexibility";
var predictor=Clazz.new_($I$(5,1));
var flexibility=predictor.calculateMolecularFlexibility$com_actelion_research_chem_StereoMolecule(mol);
this.value=Float.toString$F(flexibility);
} else if (propertyName.toLowerCase$().equals$O("complexity")) {
this.shortDisplayedPropertyName="Complexity";
this.longDisplayedPropertyName="Complexity";
this.value=$I$(2,"toString$D",[p$1.assessMolecularComplexity$com_actelion_research_chem_StereoMolecule.apply(this, [mol])]);
} else if (propertyName.replace$CharSequence$CharSequence(" ", "_").toLowerCase$().equals$O("heavy_atoms")) {
this.shortDisplayedPropertyName="Heavy atoms";
this.longDisplayedPropertyName="Heavy atoms";
this.value="" + mol.getAtoms$();
} else if (propertyName.replace$CharSequence$CharSequence(" ", "_").toLowerCase$().equals$O("noncarbon_atoms") || propertyName.toLowerCase$().equals$O("non-carbon atoms") ) {
this.shortDisplayedPropertyName="Non-carbon atoms";
this.longDisplayedPropertyName="Non-carbon atoms";
var count=0;
mol.ensureHelperArrays$I(1);
for (var atom=0; atom < mol.getAtoms$(); atom++) if (mol.getAtomicNo$I(atom) != 6) ++count;

this.value="" + count;
} else if (propertyName.replace$CharSequence$CharSequence(" ", "_").toLowerCase$().equals$O("metal_atoms")) {
this.shortDisplayedPropertyName="Metal atoms";
this.longDisplayedPropertyName="Metal atoms";
var count=0;
mol.ensureHelperArrays$I(1);
for (var atom=0; atom < mol.getAtoms$(); atom++) if (mol.isMetalAtom$I(atom)) ++count;

this.value="" + count;
} else if (propertyName.replace$CharSequence$CharSequence(" ", "_").toLowerCase$().equals$O("negative_atoms")) {
this.shortDisplayedPropertyName="Negative atoms";
this.longDisplayedPropertyName="Negative atoms";
var count=0;
mol.ensureHelperArrays$I(1);
for (var atom=0; atom < mol.getAtoms$(); atom++) if (mol.isElectronegative$I(atom)) ++count;

this.value="" + count;
} else if (propertyName.toLowerCase$().equals$O("stereocenters")) {
this.shortDisplayedPropertyName="Stereocenters";
this.longDisplayedPropertyName="Stereocenters";
this.value="" + mol.getStereoCenterCount$();
} else if (propertyName.replace$CharSequence$CharSequence(" ", "_").toLowerCase$().equals$O("rotatable_bonds") || propertyName.toLowerCase$().equals$O("rot. bonds") ) {
this.shortDisplayedPropertyName="Rot. bonds";
this.longDisplayedPropertyName="Rotatable bonds";
this.value="" + mol.getRotatableBondCount$();
} else if (propertyName.toLowerCase$().equals$O("rings")) {
this.shortDisplayedPropertyName="Rings";
this.longDisplayedPropertyName="Rings";
mol.ensureHelperArrays$I(7);
this.value="" + mol.getRingSet$().getSize$();
} else if (propertyName.replace$CharSequence$CharSequence(" ", "_").toLowerCase$().equals$O("aromatic_rings") || propertyName.toLowerCase$().equals$O("arom. rings") ) {
this.shortDisplayedPropertyName="Arom. rings";
this.longDisplayedPropertyName="Aromatic rings";
var count=0;
mol.ensureHelperArrays$I(7);
var rc=mol.getRingSet$();
for (var i=0; i < rc.getSize$(); i++) if (rc.isAromatic$I(i)) ++count;

this.value="" + count;
} else if (propertyName.replace$CharSequence$CharSequence(" ", "_").toLowerCase$().equals$O("sp3_atoms")) {
this.shortDisplayedPropertyName="SP3 atoms";
this.longDisplayedPropertyName="SP3 atoms";
var count=0;
mol.ensureHelperArrays$I(7);
for (var atom=0; atom < mol.getAtoms$(); atom++) if ((mol.getAtomicNo$I(atom) == 6 && mol.getAtomPi$I(atom) == 0 ) || (mol.getAtomicNo$I(atom) == 7 && !mol.isFlatNitrogen$I(atom) ) || (mol.getAtomicNo$I(atom) == 8 && mol.getAtomPi$I(atom) == 0  && !mol.isAromaticAtom$I(atom) ) || (mol.getAtomicNo$I(atom) == 15) || (mol.getAtomicNo$I(atom) == 16 && !mol.isAromaticAtom$I(atom) )  ) ++count;

this.value="" + count;
} else if (propertyName.replace$CharSequence$CharSequence(" ", "_").toLowerCase$().equals$O("symmetric_atoms") || propertyName.toLowerCase$().equals$O("symm. atoms") ) {
this.shortDisplayedPropertyName="Symm. atoms";
this.longDisplayedPropertyName="Symmetric atoms";
mol.ensureHelperArrays$I(63);
var maxRank=0;
for (var atom=0; atom < mol.getAtoms$(); atom++) if (maxRank < mol.getSymmetryRank$I(atom)) maxRank=mol.getSymmetryRank$I(atom);

this.value="" + (mol.getAtoms$() - maxRank);
} else if (propertyName.replace$CharSequence$CharSequence(" ", "_").toLowerCase$().equals$O("all_amides")) {
this.shortDisplayedPropertyName="All amides";
this.longDisplayedPropertyName="All amides";
var count=0;
mol.ensureHelperArrays$I(1);
for (var atom=0; atom < mol.getAtoms$(); atom++) if ($I$(6).isAmide$com_actelion_research_chem_StereoMolecule$I(mol, atom)) ++count;

this.value="" + count;
} else if (propertyName.replace$CharSequence$CharSequence(" ", "_").toLowerCase$().equals$O("all_amines")) {
this.shortDisplayedPropertyName="All amines";
this.longDisplayedPropertyName="All amines";
var count=0;
mol.ensureHelperArrays$I(7);
for (var atom=0; atom < mol.getAtoms$(); atom++) if ($I$(6).isAmine$com_actelion_research_chem_StereoMolecule$I(mol, atom)) ++count;

this.value="" + count;
} else if (propertyName.replace$CharSequence$CharSequence(" ", "_").toLowerCase$().equals$O("alkyl_amines")) {
this.shortDisplayedPropertyName="Alkyl amines";
this.longDisplayedPropertyName="Alkyl amines";
var count=0;
mol.ensureHelperArrays$I(7);
for (var atom=0; atom < mol.getAtoms$(); atom++) if ($I$(6).isAlkylAmine$com_actelion_research_chem_StereoMolecule$I(mol, atom)) ++count;

this.value="" + count;
} else if (propertyName.replace$CharSequence$CharSequence(" ", "_").toLowerCase$().equals$O("aryl_amines")) {
this.shortDisplayedPropertyName="Aryl amines";
this.longDisplayedPropertyName="Aryl amines";
var count=0;
mol.ensureHelperArrays$I(7);
for (var atom=0; atom < mol.getAtoms$(); atom++) if ($I$(6).isArylAmine$com_actelion_research_chem_StereoMolecule$I(mol, atom)) ++count;

this.value="" + count;
} else if (propertyName.replace$CharSequence$CharSequence(" ", "_").toLowerCase$().equals$O("aromatic_nitrogens") || propertyName.toLowerCase$().equals$O("arom. nitrogens") ) {
this.shortDisplayedPropertyName="Arom. nitrogens";
this.longDisplayedPropertyName="Aromatic nitrogens";
var count=0;
mol.ensureHelperArrays$I(7);
for (var atom=0; atom < mol.getAtoms$(); atom++) if (mol.getAtomicNo$I(atom) == 7 && mol.isAromaticAtom$I(atom) ) ++count;

this.value="" + count;
} else if (propertyName.replace$CharSequence$CharSequence(" ", "_").toLowerCase$().equals$O("basic_nitrogens")) {
this.shortDisplayedPropertyName="Basic nitrogens";
this.longDisplayedPropertyName="Basic nitrogens";
var count=0;
mol.ensureHelperArrays$I(7);
for (var atom=0; atom < mol.getAtoms$(); atom++) if ($I$(6).isBasicNitrogen$com_actelion_research_chem_StereoMolecule$I(mol, atom)) ++count;

this.value="" + count;
} else if (propertyName.replace$CharSequence$CharSequence(" ", "_").toLowerCase$().equals$O("acidic_nitrogens")) {
this.shortDisplayedPropertyName="Acidic nitrogens";
this.longDisplayedPropertyName="Acidic nitrogens";
var count=0;
mol.ensureHelperArrays$I(7);
for (var atom=0; atom < mol.getAtoms$(); atom++) if ($I$(6).isAcidicOxygen$com_actelion_research_chem_StereoMolecule$I(mol, atom)) ++count;

this.value="" + count;
}}, p$1);

Clazz.newMeth(C$, 'assessMolecularShape$com_actelion_research_chem_StereoMolecule',  function (mol) {
mol.ensureHelperArrays$I(7);
if (mol.getAtoms$() == 0) return -1;
if (mol.getBonds$() == 0) return 0;
var maxLength=0;
for (var atom=0; atom < mol.getAtoms$(); atom++) if (mol.getConnAtoms$I(atom) == 1 || mol.isRingAtom$I(atom) ) maxLength=Math.max(maxLength, p$1.findHighestAtomDistance$com_actelion_research_chem_StereoMolecule$I.apply(this, [mol, atom]));

return (maxLength + 1) / mol.getAtoms$();
}, p$1);

Clazz.newMeth(C$, 'assessMolecularComplexity$com_actelion_research_chem_StereoMolecule',  function (mol) {
var MAX_BOND_COUNT=7;
var bondCount=Math.min((mol.getBonds$()/2|0), 7);
mol.ensureHelperArrays$I(7);
var fragment=Clazz.new_([mol.getAtoms$(), mol.getBonds$()],$I$(7,1).c$$I$I);
var fragmentSet=Clazz.new_($I$(8,1));
var atomMap=Clazz.array(Integer.TYPE, [mol.getAllAtoms$()]);
var bondsTouch=Clazz.array(Boolean.TYPE, [mol.getBonds$(), mol.getBonds$()]);
for (var atom=0; atom < mol.getAtoms$(); atom++) {
for (var i=1; i < mol.getConnAtoms$I(atom); i++) {
for (var j=0; j < i; j++) {
var bond1=mol.getConnBond$I$I(atom, i);
var bond2=mol.getConnBond$I$I(atom, j);
bondsTouch[bond1][bond2]=true;
bondsTouch[bond2][bond1]=true;
}
}
}
var bondIsMember=Clazz.array(Boolean.TYPE, [mol.getBonds$()]);
var maxLevel=bondCount - 2;
var levelBond=Clazz.array(Integer.TYPE, [maxLevel + 1]);
for (var rootBond=0; rootBond < mol.getBonds$(); rootBond++) {
bondIsMember[rootBond]=true;
var level=0;
levelBond[0]=rootBond;
while (true){
var levelBondFound=false;
while (!levelBondFound && levelBond[level] < mol.getBonds$() - 1 ){
++levelBond[level];
if (!bondIsMember[levelBond[level]]) {
for (var bond=rootBond; bond < mol.getBonds$(); bond++) {
if (bondIsMember[bond] && bondsTouch[bond][levelBond[level]] ) {
levelBondFound=true;
break;
}}
}}
if (levelBondFound) {
bondIsMember[levelBond[level]]=true;
if (level == maxLevel) {
mol.copyMoleculeByBonds$com_actelion_research_chem_ExtendedMolecule$ZA$Z$IA(fragment, bondIsMember, true, atomMap);
fragmentSet.add$O(Clazz.new_($I$(9,1).c$$com_actelion_research_chem_StereoMolecule,[fragment]).getIDCode$());
bondIsMember[levelBond[level]]=false;
} else {
++level;
levelBond[level]=rootBond;
}} else {
if (--level < 0) break;
bondIsMember[levelBond[level]]=false;
}}
}
return Math.log(fragmentSet.size$()) / bondCount;
}, p$1);

Clazz.newMeth(C$, 'findHighestAtomDistance$com_actelion_research_chem_StereoMolecule$I',  function (mol, startAtom) {
var graphLevel=Clazz.array(Integer.TYPE, [mol.getAtoms$()]);
var graphAtom=Clazz.array(Integer.TYPE, [mol.getAtoms$()]);
graphAtom[0]=startAtom;
graphLevel[startAtom]=1;
var current=0;
var highest=0;
while (current <= highest){
var parent=graphAtom[current];
for (var i=0; i < mol.getConnAtoms$I(parent); i++) {
var candidate=mol.getConnAtom$I$I(parent, i);
if (graphLevel[candidate] == 0) {
graphAtom[++highest]=candidate;
graphLevel[candidate]=graphLevel[parent] + 1;
}}
++current;
}
return graphLevel[graphAtom[highest]] - 1;
}, p$1);

Clazz.newMeth(C$, 'getCalculatedValue$S$com_actelion_research_chem_StereoMolecule',  function (propertyName, mol) {
p$1.CalculateCompound$S$com_actelion_research_chem_StereoMolecule$I.apply(this, [propertyName, mol, -1]);
return this.value;
});

Clazz.newMeth(C$, 'getCalculatedValue$S$com_actelion_research_chem_StereoMolecule$I',  function (propertyName, mol, calculatedPropertyAttributeIndex) {
p$1.CalculateCompound$S$com_actelion_research_chem_StereoMolecule$I.apply(this, [propertyName, mol, calculatedPropertyAttributeIndex]);
return this.value;
});

Clazz.newMeth(C$, 'getShortDisplayedPropertyName$',  function () {
return this.shortDisplayedPropertyName;
});

Clazz.newMeth(C$, 'getLongDisplayedPropertyName$',  function () {
return this.longDisplayedPropertyName;
});

Clazz.newMeth(C$, 'getCalculatedPropertyAttributeIndex$',  function () {
return this.calculatedPropertyAttributeIndex;
});
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:27 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
