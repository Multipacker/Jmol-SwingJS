(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ICalculateModel", null, null, 'com.actelion.research.calc.regression.ICalculateYHat');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:15 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
