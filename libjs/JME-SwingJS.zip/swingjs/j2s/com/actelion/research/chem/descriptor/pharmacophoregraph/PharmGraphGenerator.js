(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.pharmacophoregraph"),I$=[[0,'org.openmolecules.chem.conf.gen.ConformerGenerator','java.util.ArrayList','java.util.HashMap','com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreTreeGenerator','com.actelion.research.chem.descriptor.pharmacophoretree.FeatureCalculator','com.actelion.research.chem.descriptor.pharmacophoretree.TreeUtils','com.actelion.research.chem.StereoMolecule',['com.actelion.research.chem.descriptor.pharmacophoregraph.PharmGraphGenerator','.PharmAtomElements'],'com.actelion.research.chem.RingCollection','java.util.Arrays','java.util.stream.Collectors','com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreNode',['com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreTree','.BiGramInt'],'java.util.HashSet','java.util.LinkedList']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PharmGraphGenerator", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['PharmAtomElements',26]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'generateDescriptor$com_actelion_research_chem_StereoMolecule',  function (mol) {
mol.ensureHelperArrays$I(1);
mol.stripSmallFragments$();
mol.ensureHelperArrays$I(1);
$I$(1).addHydrogenAtoms$com_actelion_research_chem_StereoMolecule(mol);
var ppNodes=Clazz.new_($I$(2,1));
var nodeEdges=Clazz.new_($I$(2,1));
var atomToNodes=Clazz.new_($I$(3,1));
var atomVolumes=$I$(4).getAtomVolumes$com_actelion_research_chem_StereoMolecule(mol);
var ringNodes=Clazz.new_($I$(2,1));
var ringNodeEdges=Clazz.new_($I$(2,1));
var rings=Clazz.new_($I$(2,1));
var aromaticity=Clazz.new_($I$(3,1));
var calculator=Clazz.new_($I$(5,1).c$$com_actelion_research_chem_StereoMolecule,[mol]);
calculator.calculate$();
var functionalities=calculator.getAtomFunctionalities$();
C$.processRings$com_actelion_research_chem_StereoMolecule$java_util_List$java_util_Map$java_util_List$java_util_List$IAA$DA(mol, ringNodes, aromaticity, ringNodeEdges, rings, functionalities, atomVolumes);
for (var i=0; i < ringNodes.size$(); i++) {
var node=ringNodes.get$I(i);
$I$(4).addNode$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreNode$java_util_List$java_util_Map(node, ppNodes, atomToNodes);
}
for (var i=0; i < ringNodeEdges.size$(); i++) {
var newEdge=ringNodeEdges.get$I(i);
if (!nodeEdges.contains$O(newEdge)) nodeEdges.add$O(newEdge);
}
var heteroNodes=Clazz.new_($I$(2,1));
C$.processHeteroGroups$com_actelion_research_chem_StereoMolecule$java_util_List$IAA$DA(mol, heteroNodes, functionalities, atomVolumes);
for (var i=0; i < heteroNodes.size$(); i++) {
var node=heteroNodes.get$I(i);
$I$(4).addNode$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreNode$java_util_List$java_util_Map(node, ppNodes, atomToNodes);
}
C$.treeWalk$I$com_actelion_research_chem_StereoMolecule$java_util_Map$java_util_List$java_util_List$IAA$DA(0, mol, atomToNodes, ppNodes, nodeEdges, functionalities, atomVolumes);
var adj=$I$(6,"getAdjacencyListWithBondOrders$I$java_util_List",[ppNodes.size$(), nodeEdges]);
var pharmMol=C$.createPharmMol$java_util_List$java_util_Map(ppNodes, adj);
return pharmMol;
});

Clazz.newMeth(C$, 'createPharmMol$java_util_List$java_util_Map',  function (ppNodes, adjList) {
var pharmMol=Clazz.new_($I$(7,1));
var nodesToGraphAtoms=Clazz.new_($I$(3,1));
for (var n=0; n < ppNodes.size$(); n++) {
var atomId=-1;
if (!nodesToGraphAtoms.keySet$().contains$O(Integer.valueOf$I(n))) {
atomId=C$.addNodeToPharmGraph$com_actelion_research_chem_StereoMolecule$java_util_List$I$java_util_Map(pharmMol, ppNodes, n, nodesToGraphAtoms);
} else {
atomId=(nodesToGraphAtoms.get$O(Integer.valueOf$I(n))).$c();
}var neighbours=adjList.get$O(Integer.valueOf$I(n));
for (var nn, $nn = neighbours.keySet$().iterator$(); $nn.hasNext$()&&((nn=($nn.next$()).intValue$()),1);) {
var atomId2=-1;
if (nodesToGraphAtoms.keySet$().contains$O(Integer.valueOf$I(nn))) atomId2=(nodesToGraphAtoms.get$O(Integer.valueOf$I(nn))).$c();
 else atomId2=C$.addNodeToPharmGraph$com_actelion_research_chem_StereoMolecule$java_util_List$I$java_util_Map(pharmMol, ppNodes, nn, nodesToGraphAtoms);
var bondOrder=(neighbours.get$O(Integer.valueOf$I(nn))).$c();
pharmMol.ensureHelperArrays$I(1);
if (pharmMol.getBond$I$I(atomId, atomId2) == -1) {
if (bondOrder == 2) pharmMol.addBond$I$I$I(atomId, atomId2, 2);
 else if (bondOrder == 1) pharmMol.addBond$I$I$I(atomId, atomId2, 1);
}}
}
return pharmMol;
}, 1);

Clazz.newMeth(C$, 'addNodeToPharmGraph$com_actelion_research_chem_StereoMolecule$java_util_List$I$java_util_Map',  function (pharmGraph, nodes, nodeIndex, nodesToGraphAtoms) {
var atomID=-1;
var node=nodes.get$I(nodeIndex);
var acceptors=node.getFunctionalities$()[0];
var donors=node.getFunctionalities$()[1];
var negCharge=node.getFunctionalities$()[2];
var posCharge=node.getFunctionalities$()[3];
var totPolar=acceptors + donors + negCharge + posCharge ;
if (!node.isRing$() && totPolar > 0 ) {
atomID=pharmGraph.addAtom$I($I$(8).HETEO_GROUP.id);
nodesToGraphAtoms.put$O$O(Integer.valueOf$I(nodeIndex), Integer.valueOf$I(atomID));
C$.addPolarInfo$com_actelion_research_chem_StereoMolecule$I$I$I$I$I(pharmGraph, atomID, acceptors, donors, negCharge, posCharge);
} else if (node.isAromatic$()) {
atomID=pharmGraph.addAtom$I($I$(8).AROM_RING.id);
nodesToGraphAtoms.put$O$O(Integer.valueOf$I(nodeIndex), Integer.valueOf$I(atomID));
C$.addRingSizeInfo$com_actelion_research_chem_StereoMolecule$I$I(pharmGraph, atomID, node.getAtoms$().size$());
if (totPolar > 0) C$.addPolarInfo$com_actelion_research_chem_StereoMolecule$I$I$I$I$I(pharmGraph, atomID, acceptors, donors, negCharge, posCharge);
} else if (node.isRing$()) {
atomID=pharmGraph.addAtom$I($I$(8).RING.id);
nodesToGraphAtoms.put$O$O(Integer.valueOf$I(nodeIndex), Integer.valueOf$I(atomID));
C$.addRingSizeInfo$com_actelion_research_chem_StereoMolecule$I$I(pharmGraph, atomID, node.getAtoms$().size$());
if (totPolar > 0) C$.addPolarInfo$com_actelion_research_chem_StereoMolecule$I$I$I$I$I(pharmGraph, atomID, acceptors, donors, negCharge, posCharge);
} else if (node.isLinkNode$()) {
var linkerID=node.getFunctionalities$()[0];
switch (linkerID) {
case 1:
atomID=pharmGraph.addAtom$I($I$(8).L1.id);
nodesToGraphAtoms.put$O$O(Integer.valueOf$I(nodeIndex), Integer.valueOf$I(atomID));
break;
case 2:
atomID=pharmGraph.addAtom$I($I$(8).L2.id);
nodesToGraphAtoms.put$O$O(Integer.valueOf$I(nodeIndex), Integer.valueOf$I(atomID));
break;
case 3:
atomID=pharmGraph.addAtom$I($I$(8).L3.id);
nodesToGraphAtoms.put$O$O(Integer.valueOf$I(nodeIndex), Integer.valueOf$I(atomID));
break;
case 4:
atomID=pharmGraph.addAtom$I($I$(8).L4.id);
nodesToGraphAtoms.put$O$O(Integer.valueOf$I(nodeIndex), Integer.valueOf$I(atomID));
break;
}
} else {
atomID=pharmGraph.addAtom$I($I$(8).LIPO.id);
nodesToGraphAtoms.put$O$O(Integer.valueOf$I(nodeIndex), Integer.valueOf$I(atomID));
}return atomID;
}, 1);

Clazz.newMeth(C$, 'addRingSizeInfo$com_actelion_research_chem_StereoMolecule$I$I',  function (pharmGraph, center, ringSize) {
pharmGraph.ensureHelperArrays$I(1);
switch (ringSize) {
case 3:
var id=pharmGraph.addAtom$I($I$(8).RING3.id);
pharmGraph.addBond$I$I$I(center, id, 32);
break;
case 4:
id=pharmGraph.addAtom$I($I$(8).RING4.id);
pharmGraph.addBond$I$I$I(center, id, 32);
break;
case 5:
id=pharmGraph.addAtom$I($I$(8).RING5.id);
pharmGraph.addBond$I$I$I(center, id, 32);
break;
case 6:
id=pharmGraph.addAtom$I($I$(8).RING6.id);
pharmGraph.addBond$I$I$I(center, id, 32);
break;
case 7:
id=pharmGraph.addAtom$I($I$(8).RING7.id);
pharmGraph.addBond$I$I$I(center, id, 32);
break;
case 8:
id=pharmGraph.addAtom$I($I$(8).RING8.id);
pharmGraph.addBond$I$I$I(center, id, 32);
break;
}
pharmGraph.ensureHelperArrays$I(1);
}, 1);

Clazz.newMeth(C$, 'addPolarInfo$com_actelion_research_chem_StereoMolecule$I$I$I$I$I',  function (pharmGraph, center, acceptors, donors, chargeNeg, chargePos) {
pharmGraph.ensureHelperArrays$I(1);
for (var i=0; i < acceptors; i++) {
var id=pharmGraph.addAtom$I($I$(8).ACCEPTOR.id);
pharmGraph.addBond$I$I$I(center, id, 32);
}
for (var i=0; i < donors; i++) {
var id=pharmGraph.addAtom$I($I$(8).DONOR.id);
pharmGraph.addBond$I$I$I(center, id, 32);
}
for (var i=0; i < chargeNeg; i++) {
var id=pharmGraph.addAtom$I($I$(8).NEG_CHARGE.id);
pharmGraph.addBond$I$I$I(center, id, 32);
}
for (var i=0; i < chargePos; i++) {
var id=pharmGraph.addAtom$I($I$(8).POS_CHARGE.id);
pharmGraph.addBond$I$I$I(center, id, 32);
}
pharmGraph.ensureHelperArrays$I(1);
}, 1);

Clazz.newMeth(C$, 'processRings$com_actelion_research_chem_StereoMolecule$java_util_List$java_util_Map$java_util_List$java_util_List$IAA$DA',  function (mol, ringNodes, aromaticity, ringNodeEdges, rings, functionalities, atomVolumes) {
var rc=Clazz.new_($I$(9,1).c$$com_actelion_research_chem_ExtendedMolecule$I$I,[mol, 7, 8]);
for (var atom=0; atom < mol.getAtoms$(); atom++) {
var smallestRings=$I$(4).getSmallestRingsOfAtom$com_actelion_research_chem_RingCollection$I(rc, atom);
for (var smallRingIndex, $smallRingIndex = smallestRings.iterator$(); $smallRingIndex.hasNext$()&&((smallRingIndex=($smallRingIndex.next$())),1);) {
var smallRing=$I$(10,"stream$IA",[rc.getRingAtoms$I((smallRingIndex).$c())]).boxed$().collect$java_util_stream_Collector($I$(11).toSet$());
if (!rings.contains$O(smallRing)) {
rings.add$O(smallRing);
var isAromatic=rc.isAromatic$I((smallRingIndex).$c());
aromaticity.put$O$O(Integer.valueOf$I(rings.indexOf$O(smallRing)), Boolean.valueOf$Z(isAromatic));
}}
}
for (var ringIndex=0; ringIndex < rings.size$(); ringIndex++) {
var isAromatic=(aromaticity.get$O(Integer.valueOf$I(ringIndex))).valueOf();
var ring=rings.get$I(ringIndex);
var node=Clazz.new_([Clazz.new_($I$(2,1).c$$java_util_Collection,[ring]), functionalities, atomVolumes, true, isAromatic],$I$(12,1).c$$java_util_List$IAA$DA$Z$Z);
ringNodes.add$O(node);
}
for (var r1=0; r1 < rings.size$(); r1++) {
var ring1=rings.get$I(r1);
for (var r2=r1 + 1; r2 < rings.size$(); r2++) {
var ring2=rings.get$I(r2);
var commonElements=ring1.stream$().filter$java_util_function_Predicate(((P$.PharmGraphGenerator$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "PharmGraphGenerator$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Predicate', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['test$Integer','test$O'],  function (e) { return (this.$finals$.ring2.contains$O(e));});
})()
), Clazz.new_(P$.PharmGraphGenerator$lambda1.$init$,[this, {ring2:ring2}]))).count$();
if (Long.$gt(commonElements,0 )) {
ringNodeEdges.add$O(Clazz.new_([Clazz.array(Integer.TYPE, -1, [r1, r2]), 2],$I$(13,1).c$$IA$I));
}}
}
}, 1);

Clazz.newMeth(C$, 'processHeteroGroups$com_actelion_research_chem_StereoMolecule$java_util_List$IAA$DA',  function (mol, heteroNodes, functionalities, atomVolumes) {
for (var atom=0; atom < mol.getAtoms$(); atom++) {
if (mol.isRingAtom$I(atom)) continue;
var mergedAtoms=Clazz.new_($I$(14,1));
mergedAtoms.add$O(Integer.valueOf$I(atom));
for (var n=0; n < mol.getConnAtoms$I(atom); n++) {
var aa=mol.getConnAtom$I$I(atom, n);
if (mol.getAtomicNo$I(aa) == 7 || mol.getAtomicNo$I(aa) == 8 ) if (mol.getConnAtoms$I(aa) == 1) mergedAtoms.add$O(Integer.valueOf$I(aa));
}
if (mergedAtoms.size$() > 1) {
var node=Clazz.new_([Clazz.new_($I$(2,1).c$$java_util_Collection,[mergedAtoms]), functionalities, atomVolumes, false, false],$I$(12,1).c$$java_util_List$IAA$DA$Z$Z);
heteroNodes.add$O(node);
}}
}, 1);

Clazz.newMeth(C$, 'treeWalk$I$com_actelion_research_chem_StereoMolecule$java_util_Map$java_util_List$java_util_List$IAA$DA',  function (atom, mol, atomToNodes, ppNodes, nodeEdges, functionalities, atomVolumes) {
var visited=Clazz.array(Boolean.TYPE, [mol.getAtoms$()]);
var parents=Clazz.array(Integer.TYPE, [mol.getAtoms$()]);
var atoms=Clazz.new_($I$(15,1));
atoms.add$O(Integer.valueOf$I(atom));
parents[atom]=-1;
visited[atom]=true;
while (!atoms.isEmpty$()){
var currentAtom=(atoms.poll$()).$c();
visited[currentAtom]=true;
if (atomToNodes.get$O(Integer.valueOf$I(currentAtom)) == null ) {
var label=mol.getAtomLabel$I(currentAtom);
var node;
if ($I$(4).RGROUPS.contains$O(label)) {
node=Clazz.new_([$I$(10,"asList$OA",[Clazz.array(Integer, -1, [Integer.valueOf$I(currentAtom)])]), functionalities, atomVolumes, 7, false, false],$I$(12,1).c$$java_util_List$IAA$DA$I$Z$Z);
node.getFunctionalities$()[0]=Integer.parseInt$S(label.split$S("R")[1]);
} else {
node=Clazz.new_([$I$(10,"asList$OA",[Clazz.array(Integer, -1, [Integer.valueOf$I(currentAtom)])]), functionalities, atomVolumes, false, false],$I$(12,1).c$$java_util_List$IAA$DA$Z$Z);
}$I$(4).addNode$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreNode$java_util_List$java_util_Map(node, ppNodes, atomToNodes);
var index=ppNodes.size$() - 1;
if (parents[currentAtom] != -1) {
var connNodes=atomToNodes.get$O(Integer.valueOf$I(parents[currentAtom]));
for (var connNode, $connNode = connNodes.iterator$(); $connNode.hasNext$()&&((connNode=($connNode.next$()).intValue$()),1);) {
var newEdge=Clazz.new_([Clazz.array(Integer.TYPE, -1, [connNode, index])],$I$(13,1).c$$IA);
if (!nodeEdges.contains$O(newEdge)) nodeEdges.add$O(newEdge);
}
}} else {
var nodes=atomToNodes.get$O(Integer.valueOf$I(currentAtom));
if (parents[currentAtom] != -1) {
var connNodes=atomToNodes.get$O(Integer.valueOf$I(parents[currentAtom]));
for (var node, $node = nodes.iterator$(); $node.hasNext$()&&((node=($node.next$()).intValue$()),1);) {
for (var connNode, $connNode = connNodes.iterator$(); $connNode.hasNext$()&&((connNode=($connNode.next$()).intValue$()),1);) {
if (connNode != node) {
var newEdge=Clazz.new_([Clazz.array(Integer.TYPE, -1, [connNode, node])],$I$(13,1).c$$IA);
if (!nodeEdges.contains$O(newEdge)) nodeEdges.add$O(newEdge);
}}
}
}}for (var a=0; a < mol.getConnAtoms$I(currentAtom); a++) {
var nextAtom=mol.getConnAtom$I$I(currentAtom, a);
if (visited[nextAtom]) continue;
 else {
atoms.add$O(Integer.valueOf$I(nextAtom));
parents[nextAtom]=currentAtom;
}}
}
}, 1);
;
(function(){/*e*/var C$=Clazz.newClass(P$.PharmGraphGenerator, "PharmAtomElements", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['id']]]

Clazz.newMeth(C$, 'c$$I',  function (id) {
;C$.$init$.apply(this);
this.id=id;
}, 1);

Clazz.newMeth(C$, 'getID$',  function () {
return this.id;
});

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$$I, "ACCEPTOR", 0, [85]);
Clazz.newEnumConst($vals, C$.c$$I, "DONOR", 1, [110]);
Clazz.newEnumConst($vals, C$.c$$I, "POS_CHARGE", 2, [78]);
Clazz.newEnumConst($vals, C$.c$$I, "NEG_CHARGE", 3, [41]);
Clazz.newEnumConst($vals, C$.c$$I, "AROM", 4, [47]);
Clazz.newEnumConst($vals, C$.c$$I, "LIPO", 5, [71]);
Clazz.newEnumConst($vals, C$.c$$I, "AROM_RING", 6, [79]);
Clazz.newEnumConst($vals, C$.c$$I, "RING", 7, [44]);
Clazz.newEnumConst($vals, C$.c$$I, "L1", 8, [92]);
Clazz.newEnumConst($vals, C$.c$$I, "L2", 9, [93]);
Clazz.newEnumConst($vals, C$.c$$I, "L3", 10, [94]);
Clazz.newEnumConst($vals, C$.c$$I, "L4", 11, [95]);
Clazz.newEnumConst($vals, C$.c$$I, "RING3", 12, [31]);
Clazz.newEnumConst($vals, C$.c$$I, "RING4", 13, [32]);
Clazz.newEnumConst($vals, C$.c$$I, "RING5", 14, [30]);
Clazz.newEnumConst($vals, C$.c$$I, "RING6", 15, [36]);
Clazz.newEnumConst($vals, C$.c$$I, "RING7", 16, [49]);
Clazz.newEnumConst($vals, C$.c$$I, "RING8", 17, [50]);
Clazz.newEnumConst($vals, C$.c$$I, "HETEO_GROUP", 18, [80]);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:23 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
