(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.svm"),I$=[[0,'org.machinelearning.svm.libsvm.svm_node']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Matrix2SVMNodeConverter");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'convert$com_actelion_research_calc_Matrix',  function (A) {
var arrSVMNode=Clazz.array($I$(1), [A.rows$(), A.cols$()]);
var rows=A.rows$();
var cols=A.cols$();
for (var i=0; i < rows; i++) {
for (var j=0; j < cols; j++) {
var node=Clazz.new_($I$(1,1));
node.index=j;
node.value=A.get$I$I(i, j);
arrSVMNode[i][j]=node;
}
}
return arrSVMNode;
}, 1);

Clazz.newMeth(C$, 'convertSingleRow$DA',  function (a) {
var cols=a.length;
var arrSVMNode=Clazz.array($I$(1), [cols]);
for (var i=0; i < cols; i++) {
var node=Clazz.new_($I$(1,1));
node.index=i;
node.value=a[i];
arrSVMNode[i]=node;
}
var arrSVMNodeRow=Clazz.array($I$(1), [1, cols]);
arrSVMNodeRow[0]=arrSVMNode;
return arrSVMNodeRow;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:16 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
