(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Isotope");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['absoluteMass','percentage'],'I',['neutrones']]]

Clazz.newMeth(C$, 'c$$I$D$D',  function (neutrones, absoluteMass, percentage) {
;C$.$init$.apply(this);
this.neutrones=neutrones;
this.absoluteMass=absoluteMass;
this.percentage=percentage;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:17 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
