(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore"),I$=[[0,'com.actelion.research.chem.Coordinates']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MolDistHistVizHelper");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'centerNodes$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz',  function (mdhv) {
var barycenter=C$.getBarycenter$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz(mdhv);
for (var i=0; i < mdhv.getNumPPNodes$(); i++) {
var node=mdhv.getNode$I(i);
node.getCoordinates$().x-=barycenter.x;
node.getCoordinates$().y-=barycenter.y;
node.getCoordinates$().z-=barycenter.z;
}
var m=mdhv.getMolecule$();
var arrCoordinates=m.getCoordinates$();
for (var i=0; i < arrCoordinates.length; i++) {
var c=arrCoordinates[i];
c.x-=barycenter.x;
c.y-=barycenter.y;
c.z-=barycenter.z;
m.setCoordinates$I$com_actelion_research_chem_Coordinates(i, c);
}
}, 1);

Clazz.newMeth(C$, 'getBarycenter$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz',  function (mdhv) {
var arrCoordinates=Clazz.array($I$(1), [mdhv.getNumPPNodes$()]);
for (var i=0; i < mdhv.getNumPPNodes$(); i++) {
var node=mdhv.getNode$I(i);
arrCoordinates[i]=node.getCoordinates$();
}
return $I$(1).createBarycenter$com_actelion_research_chem_CoordinatesA(arrCoordinates);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:22 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
